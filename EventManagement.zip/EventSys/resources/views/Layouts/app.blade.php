<!DOCTYPE html>
<html>
	<head> 
		<title> Layout </title>
		<link rel="stylesheet" href="/css/app.css">
	</head>
	
	<body>
		@yield('content')
	</body>
</html>