;

<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">
            Create Event
        </div>
        <p><?php echo e($event); ?></p>
        <?php
            echo("Hello world");
        ?>    


        <?php if($type == 0): ?>
            <p>This is the create event page</p>
        <?php elseif($type == 1): ?>
            <p>This is the view event page</p>
        <?php else: ?>
            <p>Page unavailable</p>
        <?php endif; ?>

        <?php if (! ($event == 'create')): ?>
            <p>Do you want to visist the create page?</p>
        <?php endif; ?>
        <p>
        <?php for($i = 0; $i < 3; $i++): ?>
            <?php echo e($i); ?>

        <?php endfor; ?>
        </p>
        <div class="links">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vrok\Desktop\INTI documents\Agile Development\EventSys\resources\views/create.blade.php ENDPATH**/ ?>