;

<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <div class="content">
        <div class="title m-b-md">
            View Event <?php echo e($id); ?>

        </div>
    </div>
</div>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vrok\Desktop\INTI documents\Agile Development\EventSys\resources\views/event.blade.php ENDPATH**/ ?>