<!--<!DOCTYPE HTML>
<html>
	<head>
	<title> Login Page </title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="/Layouts/app.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style type="text/css">
	   .box{
		width:600px;
		margin:0 auto;
		border:1px solid #ccc;
	   }
	</style>
	</head>
	<body>
-->
;

<?php $__env->startSection('content'); ?>
		<div class="container box">
			<br>
			<h3 align="center">Login</h3>
			<h5 align="center"><?php echo e(session('msg')); ?></h5>

			<form method="post" action="login">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
			 <label>Student ID</label>
			 <input type="text" name="id" class="form-control" />
			</div>
			<div class="form-group">
			 <label>Password</label>
			 <input type="password" name="password" class="form-control" />
			</div>
			<div class="form-group">
			 <input type="submit" name="login" class="btn btn-primary" value="Login" />
			</div>
			<h5><?php echo e(session('error')); ?></h5>
		   </form>
		</div>
<?php $__env->stopSection(); ?>
	<!--</body>
</html>-->

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vrok\Desktop\INTI documents\Agile Development\EventSys\resources\views/login.blade.php ENDPATH**/ ?>